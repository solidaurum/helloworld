﻿namespace FDMTermProject.Controls
{
    /// <summary>
    /// This control allows a user to create a TradeRule
    /// </summary>
    public partial class TradeRuleControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Component Designer generated code

        private System.Windows.Forms.ComboBox Indicator1;
        private System.Windows.Forms.ComboBox Indicator2;
        private System.Windows.Forms.ComboBox IndicatorCompareType;
        private System.Windows.Forms.CheckBox ShowConstant;
        private System.Windows.Forms.TextBox ConstantIndicator;
        private System.Windows.Forms.ComboBox JoinCondition;
        private System.Windows.Forms.Label ConstantLabel;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Indicator1 = new System.Windows.Forms.ComboBox();
            this.Indicator2 = new System.Windows.Forms.ComboBox();
            this.IndicatorCompareType = new System.Windows.Forms.ComboBox();
            this.ShowConstant = new System.Windows.Forms.CheckBox();
            this.ConstantIndicator = new System.Windows.Forms.TextBox();
            this.JoinCondition = new System.Windows.Forms.ComboBox();
            this.ConstantLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Indicator1
            // 
            this.Indicator1.FormattingEnabled = true;
            this.Indicator1.Location = new System.Drawing.Point(0, 0);
            this.Indicator1.Name = "Indicator1";
            this.Indicator1.Size = new System.Drawing.Size(200, 21);
            this.Indicator1.TabIndex = 0;
            // 
            // Indicator2
            // 
            this.Indicator2.FormattingEnabled = true;
            this.Indicator2.Location = new System.Drawing.Point(335, 0);
            this.Indicator2.Name = "Indicator2";
            this.Indicator2.Size = new System.Drawing.Size(200, 21);
            this.Indicator2.TabIndex = 1;
            // 
            // IndicatorCompareType
            // 
            this.IndicatorCompareType.FormattingEnabled = true;
            this.IndicatorCompareType.Location = new System.Drawing.Point(206, 0);
            this.IndicatorCompareType.Name = "IndicatorCompareType";
            this.IndicatorCompareType.Size = new System.Drawing.Size(106, 21);
            this.IndicatorCompareType.TabIndex = 2;
            // 
            // ShowConstant
            // 
            this.ShowConstant.AutoSize = true;
            this.ShowConstant.Location = new System.Drawing.Point(318, 3);
            this.ShowConstant.Name = "ShowConstant";
            this.ShowConstant.Size = new System.Drawing.Size(15, 14);
            this.ShowConstant.TabIndex = 3;
            this.ShowConstant.UseVisualStyleBackColor = true;
            this.ShowConstant.CheckedChanged += new System.EventHandler(this.ShowConstant_CheckedChanged);
            // 
            // ConstantIndicator
            // 
            this.ConstantIndicator.Location = new System.Drawing.Point(408, 0);
            this.ConstantIndicator.Name = "ConstantIndicator";
            this.ConstantIndicator.Size = new System.Drawing.Size(94, 20);
            this.ConstantIndicator.TabIndex = 4;
            this.ConstantIndicator.Visible = false;
            // 
            // JoinCondition
            // 
            this.JoinCondition.FormattingEnabled = true;
            this.JoinCondition.Location = new System.Drawing.Point(550, 1);
            this.JoinCondition.Name = "JoinCondition";
            this.JoinCondition.Size = new System.Drawing.Size(70, 21);
            this.JoinCondition.TabIndex = 5;
            this.JoinCondition.Visible = false;
            // 
            // ConstantLabel
            // 
            this.ConstantLabel.AutoSize = true;
            this.ConstantLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConstantLabel.Location = new System.Drawing.Point(339, 2);
            this.ConstantLabel.Name = "ConstantLabel";
            this.ConstantLabel.Size = new System.Drawing.Size(63, 16);
            this.ConstantLabel.TabIndex = 6;
            this.ConstantLabel.Text = "Constant:";
            this.ConstantLabel.Visible = false;
            // 
            // TradeRuleControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ConstantLabel);
            this.Controls.Add(this.JoinCondition);
            this.Controls.Add(this.ConstantIndicator);
            this.Controls.Add(this.ShowConstant);
            this.Controls.Add(this.IndicatorCompareType);
            this.Controls.Add(this.Indicator2);
            this.Controls.Add(this.Indicator1);
            this.Name = "TradeRuleControl";
            this.Size = new System.Drawing.Size(622, 23);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}
