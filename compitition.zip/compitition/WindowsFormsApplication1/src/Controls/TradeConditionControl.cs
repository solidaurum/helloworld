﻿namespace FDMTermProject.Controls
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Windows.Forms;
    using FDMTermProject.Entities;
    using FDMTermProject.Entities.TradeRules;

    /// <summary>
    /// This control holds a variable number of TradeRuleControls
    /// </summary>
    public partial class TradeConditionControl : UserControl
    {
        /// <summary>
        /// An array of indicator names that the combo boxes have to choose from
        /// </summary>
        private string[] indicatorNames;

        /// <summary>
        /// A stack to keep track of the TradeRuleControls
        /// </summary>
        private Stack<TradeRuleControl> tradeRules;

        /// <summary>
        /// Initializes a new instance of the TradeConditionControl class
        /// </summary>
        public TradeConditionControl()
        {
            this.InitializeComponent();
            this.tradeRules = new Stack<TradeRuleControl>();
        }
        
        /// <summary>
        /// Gets or sets title label of the control
        /// </summary>
        public string Title
        {
            get
            {
                return this.TitleLabel.Text;
            }

            set
            {
                this.TitleLabel.Text = value;
            }
        }

        /// <summary>
        /// Set the values of the indicator comboboxes with the supplied array
        /// </summary>
        /// <param name="names">A string of indicator names to set the combo options to</param>
        public void SetIndicatorNames(string[] names)
        {
            Array.Sort(names);
            this.indicatorNames = names; 
            this.Reset();
        }

        /// <summary>
        /// Generates and returns a TradeCondition using the values of the controls
        /// </summary>
        /// <returns>TradeCondition object</returns>
        public Entities.TradeCondition GenerateTradeCondition()
        {
            try
            {
                TradeCondition tc = new TradeCondition();
                TradeRuleControl[] tradeRuleArray = this.tradeRules.ToArray();
                if (tradeRuleArray.Length == 0)
                {
                    return null;
                }

                foreach (TradeRuleControl tradeRuleControl in tradeRuleArray.Reverse<TradeRuleControl>())
                {
                    TradeRule tradeRule = tradeRuleControl.GetTradeRule();
                    if (tradeRule == null)
                    {
                        return null;
                    }

                    tc.Add(tradeRule, tradeRuleControl.GetRuleJoinType());
                }

                return tc;
            }
            catch (TradeRuleException ex)
            {
                throw new TradeRuleException(ex.Message, ex);
            }
        }

        /// <summary>
        /// Resets the panel to one blank TradeRuleControl
        /// </summary>
        public void Reset()
        {
            while (this.tradeRules.Count > 0)
            {
                this.RemoveLastTradeRuleControl();
            }

            this.AddNewTradeRuleControl();
        }

        /// <summary>
        /// Set the trade condition control to a specified trade condition.
        /// </summary>
        /// <param name="tradeCondition">The trade condition to set the control to.</param>
        public void SetControlsToCondition(TradeCondition tradeCondition)
        {
            List<TradeRule> tradeRuleList = tradeCondition.TradeRules;
            List<RuleJoinType> joinTypeList = tradeCondition.RuleJoinTypes;

            if (this.tradeRules.Count > 0)
            {
                this.Reset();
                if (joinTypeList.Count == 0)
                {
                    this.tradeRules.Peek().SetControlsToTradeRule(tradeRuleList[0], RuleJoinType.none);
                }
                else
                {
                    this.tradeRules.Peek().SetControlsToTradeRule(tradeRuleList[0], joinTypeList[0]);
                }
                for (int count = 1; count < tradeRuleList.Count; count++)
                {
                    this.AddNewTradeRuleControl();
                    if (count > joinTypeList.Count-1)
                    {
                        this.tradeRules.Peek().SetControlsToTradeRule(tradeRuleList[count], RuleJoinType.none);
                    }
                    else
                    {
                        this.tradeRules.Peek().SetControlsToTradeRule(tradeRuleList[count], joinTypeList[count]);
                    }
                }
            }
        }

        /// <summary>
        /// Handles the Add button click event
        /// </summary>
        /// <param name="sender">Add button</param>
        /// <param name="e">The required EventArgs argument</param>
        private void Add_Click(object sender, EventArgs e)
        {
            this.AddNewTradeRuleControl();
        }

        /// <summary>
        /// Add a TradeRuleControl to the bottom of the panel
        /// </summary>
        private void AddNewTradeRuleControl()
        {
            TradeRuleControl tradeRule = new TradeRuleControl();
            if (this.indicatorNames != null)
            {
                tradeRule.SetIndicatorNames(this.indicatorNames);
            }

            if (this.tradeRules.Count > 0)
            {
                this.tradeRules.Peek().JoinConditionVisibility = true;
            }

            this.tradeRules.Push(tradeRule);

            this.TradeRulePanel.Controls.Add(tradeRule);
        }

        /// <summary>
        /// Handles the RemoveLast button click event
        /// </summary>
        /// <param name="sender">RemoveLast button</param>
        /// <param name="e">The required EventArgs argument</param>
        private void RemoveLast_Click(object sender, EventArgs e)
        {
            this.RemoveLastTradeRuleControl();
        }

        
        /// <summary>
        /// Remove the last TradeRuleControl in the list
        /// </summary>
        private void RemoveLastTradeRuleControl()
        {
            if (this.tradeRules.Count > 0)
            {
                TradeRuleControl tradeRule = this.tradeRules.Pop();
                this.TradeRulePanel.Controls.Remove(tradeRule);
                tradeRule.Dispose();
                if (this.tradeRules.Count > 0)
                {
                    tradeRule = this.tradeRules.Peek();
                    tradeRule.JoinConditionVisibility = false;
                }
            }

            if (this.tradeRules.Count > 0)
            {
                TradeRuleControl tradeRule = this.tradeRules.Peek();
                tradeRule.SetJoinConditionToDefault();
                
            }
        }

        /// <summary>
        /// Sets the focus to the panel when the mouse enters it
        /// </summary>
        /// <param name="sender">The sender parameter</param>
        /// <param name="e">The required EventArgs argument</param>
        private void TradeRulePanel_Click(object sender, EventArgs e)
        {
            this.TradeRulePanel.Focus();
        }
    }
}
