﻿namespace FDMTermProject.Controls
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Windows.Forms;
    using FDMTermProject.Entities;
    using FDMTermProject.Entities.TradeRules; 

    /// <summary>
    /// This control allows a user to create a TradeRule
    /// </summary>
    public partial class TradeRuleControl : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the TradeRuleControl class
        /// </summary>
        public TradeRuleControl()
        {
            this.InitializeComponent();
            this.IndicatorCompareType.DataSource = System.Enum.GetValues(typeof(IndicatorCompareType));
            this.JoinCondition.Items.Add(RuleJoinType.and);
            this.JoinCondition.Items.Add(RuleJoinType.or);
            this.SetJoinConditionToDefault();
        }

        /// <summary>
        /// Gets or sets a value indicating whether the join condition combo box is visible
        /// </summary>
        public bool JoinConditionVisibility
        {
            get
            {
                return this.JoinCondition.Visible;
            }

            set
            {
                this.JoinCondition.Visible = value;
            }
        }

        /// <summary>
        /// Set the names of the indicators with the supplied string array
        /// </summary>
        /// <param name="names">A string array of the indicator names</param>
        public void SetIndicatorNames(string[] names)
        {
            this.Indicator1.Items.Clear();
            this.Indicator2.Items.Clear();
            this.Indicator1.Items.AddRange(names);
            this.Indicator2.Items.AddRange(names);
        }


        /// <summary>
        /// Set the join condition to DEFAULTJOINTYPE
        /// </summary>
        public void SetJoinConditionToDefault()
        {
            this.JoinCondition.SelectedItem = null;
        }

        /// <summary>
        /// Generate a trade rule based on the values of the controls
        /// </summary>
        /// <returns>A TradeRule object</returns>
        public TradeRule GetTradeRule()
        {
            if (this.Indicator1.SelectedItem == null)
            {
                return null;
            }

            if (this.ShowConstant.Checked == true)
            {
                double constant;
                if (!double.TryParse(this.ConstantIndicator.Text, out constant))
                {
                    return null;
                }

                return TradeRuleFactory.GenerateTradeRule(this.Indicator1.SelectedItem.ToString(), (IndicatorCompareType)this.IndicatorCompareType.SelectedItem, "#" + constant);
            }
            else
            {
                if (this.Indicator2.SelectedItem == null)
                {
                    return null;
                }

                return TradeRuleFactory.GenerateTradeRule(this.Indicator1.SelectedItem.ToString(), (IndicatorCompareType)this.IndicatorCompareType.SelectedItem, this.Indicator2.SelectedItem.ToString());
            }
        }

        /// <summary>
        /// Get the rule join type
        /// </summary>
        /// <returns>A value of RuleJoinType</returns>
        public RuleJoinType GetRuleJoinType()
        {
            if (this.JoinCondition.SelectedItem == null)
            {
                return RuleJoinType.none;
            }
            
            return (RuleJoinType)this.JoinCondition.SelectedItem;
        }

        /// <summary>
        /// Sets the control to the loaded trade rule and rule join type.
        /// </summary>
        /// <param name="tradeRule">The trade rule to set the control to.</param>
        /// <param name="ruleJoinType">The rule join type to set the control to.</param>
        internal void SetControlsToTradeRule(TradeRule tradeRule, RuleJoinType ruleJoinType)
        {
            try
            {
                double constantValue;
                this.Indicator1.SelectedItem = tradeRule.IndicatorName1;
                this.IndicatorCompareType.SelectedItem = tradeRule.CompareType;
                if (tradeRule.IndicatorName2.Substring(0, 1) == "#" && Double.TryParse(tradeRule.IndicatorName2.Remove(0, 1), out constantValue))
                {
                    this.ShowConstant.Checked = true;
                    this.ConstantIndicator.Text = constantValue.ToString();
                }
                else
                {
                    this.Indicator2.SelectedItem = tradeRule.IndicatorName2;
                }

                this.JoinCondition.SelectedItem = ruleJoinType;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Handles the checked changed event of ShowConstant
        /// </summary>
        /// <param name="sender">Sender parameter</param>
        /// <param name="e">EventArgs parameter</param>
        private void ShowConstant_CheckedChanged(object sender, EventArgs e)
        {
            if (this.ConstantIndicator.Visible)
            {
                this.ConstantLabel.Visible = false;
                this.ConstantIndicator.Visible = false;
                this.Indicator2.Visible = true;
            }
            else
            {
                this.ConstantLabel.Visible = true;
                this.ConstantIndicator.Visible = true;
                this.Indicator2.Visible = false;
            }
        }
    }
}
