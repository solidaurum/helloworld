﻿namespace FDMTermProject.Library
{
    using System;
    using System.Windows.Forms;

    /// <summary>
    /// A custom control having two NumericUpDown controls one the high and one the low.
    /// Each one (low/high) is the respective limit for the other.
    /// </summary>
    public partial class HighLowNumericUpDown : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the HighLowNumericUpDown class.
        /// </summary>
        public HighLowNumericUpDown()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Gets or sets the maximum value for the high.
        /// </summary>
        public decimal Maximum
        {
            get
            {
                return this.high.Maximum;
            }

            set
            {
                this.high.Maximum = value;
            }
        }

        /// <summary>
        /// Gets or sets the minimum value for the low.
        /// </summary>
        public decimal Minimum
        {
            get
            {
                return this.low.Minimum;
            }

            set
            {
                this.low.Minimum = value;
            }
        }

        /// <summary>
        /// Gets or sets the high value.
        /// </summary>
        public decimal High
        {
            get
            {
                return this.high.Value;
            }

            set 
            {
                this.high.Value = value;
            }
        }

        /// <summary>
        /// Gets or sets the low value.
        /// </summary>
        public decimal Low
        {
            get
            {
                return this.low.Value;
            }

            set
            {
                this.low.Value = value;
            }
        }

        /// <summary>
        /// Gets or sets the increment for the high and low.
        /// </summary>
        public decimal Increment
        {
            get
            {
                return this.low.Increment;
            }

            set
            {
                this.low.Increment = value;
                this.high.Increment = value;

                // Set the number of decimal places on high and low based on the increment.
                string stringValue = value.ToString();
                int decimalPlaces = stringValue.Length - (stringValue.IndexOf('.') + 1);
                if (stringValue.IndexOf('.') < 0)
                {
                    decimalPlaces = 0;
                }

                this.low.DecimalPlaces = decimalPlaces;
                this.high.DecimalPlaces = decimalPlaces;
            }
        }

        /// <summary>
        /// Event to set the high's minimum when low changes.
        /// </summary>
        /// <param name="sender">Event Sender</param>
        /// <param name="e">Event Arguements</param>
        private void Low_ValueChanged(object sender, EventArgs e)
        {
            this.high.Minimum = this.low.Value;
        }

        /// <summary>
        /// Event to set the low's minimum when high changes.
        /// </summary>
        /// <param name="sender">Event Sender</param>
        /// <param name="e">Event Arguments</param>
        private void High_ValueChanged(object sender, EventArgs e)
        {
            this.low.Maximum = this.high.Value;
        }
    }
}
