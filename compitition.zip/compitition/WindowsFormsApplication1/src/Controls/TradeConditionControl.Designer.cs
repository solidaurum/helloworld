﻿namespace FDMTermProject.Controls
{
    /// <summary>
    /// This control holds a variable number of TradeRuleControls
    /// </summary>
    public partial class TradeConditionControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
      
        #region Component Designer generated code

        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button RemoveLast;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.FlowLayoutPanel TradeRulePanel;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RemoveLast = new System.Windows.Forms.Button();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.TradeRulePanel = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(3, 109);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 1;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(0, 0);
            this.panel1.TabIndex = 2;
            // 
            // RemoveLast
            // 
            this.RemoveLast.Location = new System.Drawing.Point(84, 109);
            this.RemoveLast.Name = "RemoveLast";
            this.RemoveLast.Size = new System.Drawing.Size(92, 23);
            this.RemoveLast.TabIndex = 3;
            this.RemoveLast.Text = "Remove Last";
            this.RemoveLast.UseVisualStyleBackColor = true;
            this.RemoveLast.Click += new System.EventHandler(this.RemoveLast_Click);
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleLabel.Location = new System.Drawing.Point(187, 108);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(182, 25);
            this.TitleLabel.TabIndex = 4;
            this.TitleLabel.Text = "Buy or Sell Rule";
            // 
            // TradeRulePanel
            // 
            this.TradeRulePanel.AutoScroll = true;
            this.TradeRulePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TradeRulePanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.TradeRulePanel.Location = new System.Drawing.Point(0, 0);
            this.TradeRulePanel.Name = "TradeRulePanel";
            this.TradeRulePanel.Size = new System.Drawing.Size(649, 100);
            this.TradeRulePanel.TabIndex = 5;
            this.TradeRulePanel.WrapContents = false;
            this.TradeRulePanel.Click += new System.EventHandler(this.TradeRulePanel_Click);
            // 
            // TradeConditionControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.TradeRulePanel);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.RemoveLast);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Add);
            this.Name = "TradeConditionControl";
            this.Size = new System.Drawing.Size(649, 140);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
    }
}
