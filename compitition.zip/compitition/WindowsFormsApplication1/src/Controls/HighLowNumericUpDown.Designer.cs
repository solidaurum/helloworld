﻿namespace FDMTermProject.Library
{
    /// <summary>
    /// Designer partial class
    /// </summary>
    public partial class HighLowNumericUpDown
    {
        #region Component Designer generated code

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.low = new System.Windows.Forms.NumericUpDown();
            this.high = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.low)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.high)).BeginInit();
            this.SuspendLayout();
            // 
            // Low
            // 
            this.low.Location = new System.Drawing.Point(0, 0);
            this.low.Name = "Low";
            this.low.Size = new System.Drawing.Size(50, 20);
            this.low.TabIndex = 0;
            this.low.ValueChanged += new System.EventHandler(this.Low_ValueChanged);
            // 
            // High
            // 
            this.high.Location = new System.Drawing.Point(63, 0);
            this.high.Name = "High";
            this.high.Size = new System.Drawing.Size(50, 20);
            this.high.TabIndex = 1;
            this.high.ValueChanged += new System.EventHandler(this.High_ValueChanged);
            // 
            // HighLowNumericUpDown
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.high);
            this.Controls.Add(this.low);
            this.Name = "HighLowNumericUpDown";
            this.Size = new System.Drawing.Size(113, 20);
            ((System.ComponentModel.ISupportInitialize)(this.low)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.high)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.NumericUpDown low;
        private System.Windows.Forms.NumericUpDown high;

        #endregion
    }
}
